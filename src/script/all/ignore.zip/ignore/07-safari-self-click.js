/*
@ safari self click */

eval(function(p,a,c,k,e,r){e=function(c){return c.toString(a)};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('(2(a,b,c){5(c 3 b&&b[c]){6 d,e=a.7,f=/^(a|8)$/i;a.9("g",2(a){d=a.h;j(!f.k(d.l))d=d.m;"0"3 d&&(d.0.4("n")||~d.0.4(e.o))&&(a.p(),e.0=d.0)},!1)}})(q,r.s,"t");',30,30,'href||function|in|indexOf|if|var|location|html|addEventListener|||||||click|target||while|test|nodeName|parentNode|http|host|preventDefault|document|window|navigator|standalone'.split('|'),0,{}));
